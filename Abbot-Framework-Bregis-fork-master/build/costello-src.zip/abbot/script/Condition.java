package abbot.script;

/** @deprecated Use abbot.util.Condition instead. */
public interface Condition extends abbot.util.Condition { }
