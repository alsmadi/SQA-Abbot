package abbot;
 
/** Current version of the framework. */

public interface Version {
    String VERSION = "1.4.0-SNAPSHOT";
}







