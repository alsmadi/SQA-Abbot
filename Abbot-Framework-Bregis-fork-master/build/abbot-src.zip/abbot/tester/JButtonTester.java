package abbot.tester;

import javax.swing.JButton;

/**
 * Provides action methods and assertions for {@link JButton}s.
 * 
 * @author tlroche
 * @version $Id: JButtonTester.java 1419 2005-01-05 18:34:48Z twall $
 */
public class JButtonTester extends AbstractButtonTester {
}
